import 'package:flutter/material.dart';
import 'database_helper.dart'; // Import the DatabaseHelper class
import 'user.dart'; // Import the User class

void main() async {
  // Initialize the database and insert users
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseHelper.instance.initDb();
  await DatabaseHelper.instance.initializeUsers();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'User Management',
      home: UserList(),
    );
  }
}

class UserList extends StatefulWidget {
  const UserList({super.key});

  @override
  _UserListState createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  List<User> _users = [];

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    final userMaps = await DatabaseHelper.instance.queryAllUsers();
    setState(() {
      _users = userMaps.map((userMap) => User.fromMap(userMap)).toList();
    });
  }

  // Function to handle delete user action
  Future<void> _deleteUser(int userId) async {
    await DatabaseHelper.instance.deleteUser(userId);
    _fetchUsers(); // Refresh the user list
  }

  // Function to handle edit user action
  void _editUser(User user) {
    TextEditingController usernameController =
        TextEditingController(text: user.username);
    TextEditingController emailController =
        TextEditingController(text: user.email);
    TextEditingController pwdController = TextEditingController(text: user.pwd);
    TextEditingController weightController =
        TextEditingController(text: user.weight.toString());
    TextEditingController heightController =
        TextEditingController(text: user.height.toString());

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit User'),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: usernameController,
                decoration: const InputDecoration(labelText: 'Username'),
              ),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              TextField(
                controller: pwdController,
                decoration: const InputDecoration(labelText: 'Password'),
              ),
              TextField(
                  controller: weightController,
                  decoration: const InputDecoration(labelText: 'Weight (kg)')),
              TextField(
                  controller: heightController,
                  decoration: const InputDecoration(labelText: 'Height (cm)')),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final double weight = double.parse(weightController.text);
                final double height = double.parse(heightController.text);
                //final double whNum = 111.0;

                final updatedUser = User(
                  id: user.id, // Keep the same id to update the correct record
                  username: usernameController.text,
                  email: emailController.text,
                  pwd: pwdController.text,
                  weight: double.parse(weightController.text),
                  height: double.parse(heightController.text),
                  //wh: whNum,
                );
                DatabaseHelper.instance.updateUser(updatedUser).then((value) {
                  _fetchUsers(); // Refresh the user list
                });
                Navigator.pop(context); // Close the dialog
              },
              child: const Text('Save'),
            ),
            TextButton(
              onPressed: () =>
                  Navigator.pop(context), // Close the dialog without saving
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void _addUser() {
    TextEditingController usernameController = TextEditingController();
    TextEditingController emailController = TextEditingController();
    TextEditingController pwdController = TextEditingController();
    TextEditingController weightController = TextEditingController();
    TextEditingController heightController = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New User'),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: usernameController,
                decoration: const InputDecoration(labelText: 'Username'),
              ),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              TextField(
                controller: pwdController,
                decoration: const InputDecoration(labelText: 'Password'),
              ),
              TextField(
                  controller: weightController,
                  decoration: const InputDecoration(labelText: 'Weight (kg)')),
              TextField(
                  controller: heightController,
                  decoration: const InputDecoration(labelText: 'Height (cm)')),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final double weight = double.parse(weightController.text);
                final double height = double.parse(heightController.text);
                //final double whNum = 111.0;

                final newUser = User(
                  username: usernameController.text,
                  email: emailController.text,
                  pwd: pwdController.text,
                  weight: double.parse(weightController.text),
                  height: double.parse(heightController.text),
                  //wh: whNum,
                );
                DatabaseHelper.instance.insertUser(newUser).then((value) {
                  _fetchUsers(); // Refresh the user list
                });
                Navigator.pop(context); // Close the dialog
              },
              child: const Text('Add'),
            ),
            TextButton(
              onPressed: () =>
                  Navigator.pop(context), // Close the dialog without adding
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteAllUsers() async {
    await DatabaseHelper.instance.deleteAllUsers(); // ลบข้อมูลผู้ใช้ทั้งหมด
    _fetchUsers(); // อัปเดตข้อมูลใหม่
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Show User List'),
        backgroundColor: const Color.fromARGB(255, 6, 207, 252),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_forever),
            onPressed: _deleteAllUsers, // ลบข้อมูลทั้งหมดเมื่อกด
            color: Colors.red,
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _users.length,
        itemBuilder: (context, index) {
          final user = _users[index];
          return ListTile(
            leading: const Icon(
              Icons.account_circle,
              color: Colors.cyan,
            ),
            title: Text("Username : ${user.username}"),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 5),
                Text("Email : ${user.email}"),
                const SizedBox(height: 5),
                Text("Password : ${user.pwd}"),
                const SizedBox(height: 5),
                Text("Weight: ${user.weight} kg"),
                const SizedBox(height: 5),
                Text("Height: ${user.height} cm"),
                const SizedBox(height: 5),
                //Text("WH: ${user.wh} data"),
                //const SizedBox(height: 5),
                //Text("DateTime : ${user.createAt}"),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _editUser(user), // Edit action
                  color: Colors.blue,
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => _deleteUser(user.id!), // Delete action
                  color: Colors.red,
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addUser,
        backgroundColor: const Color.fromARGB(255, 7, 174, 221),
        child: const Icon(Icons.add),
      ),
    );
  }
}
